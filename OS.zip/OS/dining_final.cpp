#include <iostream>
using namespace std;

int p[5];   // Philosopher state: 0 = thinking, 1 = eating
int ch[5];  // Chopstick state: 0 = free, 1 = busy

void signal(int z)
{
    int j = (z + 1) % 5;

    p[z] = 0;      // philosopher stops eating
    ch[z] = 0;     // left chopstick free
    ch[j] = 0;     // right chopstick free
}

void wait(int y)
{
    int r = (y + 1) % 5;

    if ((ch[y] == 0) && (ch[r] == 0))
    {
        p[y] = 1;     // philosopher starts eating
        ch[y] = 1;    // left chopstick taken
        ch[r] = 1;    // right chopstick taken
    }
    else if (p[y] == 1)
    {
        int w;
        cout << "Do you want philosopher " << y << " to stop eating (1=yes)? ";
        cin >> w;

        if (w == 1)
            signal(y);
    }
    else
    {
        cout << "Chopsticks " << y << " and " << r << " are busy" << endl;
        cout << "Philosopher " << y << " has to wait" << endl;
    }
}

int main()
{
    int i, u;

    // Initialize
    for (i = 0; i < 5; i++)
    {
        p[i] = 0;   // thinking
        ch[i] = 0;  // chopsticks free
    }

    do
    {
        for (i = 0; i < 5; i++)
        {
            if (p[i] == 0)
                cout << "Philosopher " << i << " is thinking\n\n";
            else
                cout << "Philosopher " << i << " is eating\n\n";
        }

        int s;
        cout << "Which philosopher wants to eat: ";
        cin >> s;

        wait(s);

        cout << "Do you want to continue? Press 1: ";
        cin >> u;

    } while (u == 1);

    return 0;
}
