#include<bits/stdc++.h>
using namespace std;
#define SIZE 4
int buffer [SIZE];
int in=0,out=0;
int empty=SIZE;
int mutex=1;
int full=0;

int wait(int s)
{
  while(s<=0);
  s=s-1;
  return s;
}
int signal(int s)
{
  s=s+1;
  return s;
}

int producer(int item)
{
    if(empty==0)
    {
      cout<<"BUffer full"<<endl;
    }
    else
    {
      empty=wait(empty);
      mutex=wait(mutex);
      buffer[in]=item;
      in=(in+1)%SIZE;
      cout<<"produce"<<item<<endl;
      mutex=signal(mutex);
      full=signal(full);
    }
}
void consumer()
{
  if(full==0)
  {
    cout<<"Buffer empty"<<endl;
  }
  else{
    full=wait(full);
    mutex=wait(mutex);
    int item=buffer[out];
    cout<<"consumer"<<item<<endl;
    mutex=signal(mutex);
    empty=signal(empty);
  }
}
int main()
{
  producer(20);
  producer(30);
  producer(10);
  consumer();
  consumer();

}