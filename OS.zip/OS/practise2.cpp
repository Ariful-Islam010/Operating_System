#include<bits/stdc++.h>
using namespace std;
int chop[5]={1,1,1,1,1};

void think(int in)
{
  cout<<"philo"<<in+1<<"is thinking"<<endl;
}
void eat(int in)
{
  cout<<"philo"<<in+1<<"is thinking"<<endl;
}
void wait( int id)
{
  while(chop[id]==0);
  chop[id]=0;
}
void signal(int id)
{
  chop[id]=1;
}


void philo(int id)
{
  int t;
  for(t=0;t<2;t++)
  {
    think(id);
    wait(id);
    wait((id+1)%5);
    eat(id);
    signal(id);
    signal((id+1)%5);
  }
}


int main()
{
  int i;
  for(i=0;i<5;i++)
  {
    philo(i);
  }
}